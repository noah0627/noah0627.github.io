#  凯撒加密器.py, v2.0.1 , 2025-10-13
#  © 版权所有 2025.10  Noah. 保留所有权利。
#  © 部分版权所有 2025 新东方教育科技集团有限公司。

import tkinter as tk
import tkinter.messagebox as tkm
from tkinter import ttk
import webbrowser

def encrypt():
    window2 = tk.Toplevel()  # 使用Toplevel而不是Tk创建新窗口
    window2.title("加密")
    window2.geometry("500x200")

    label = ttk.Label(window2, text="请输入需要加密的文件名（不加后缀）：", font=('微软雅黑', 12))
    label.pack(pady=10)

    entry = ttk.Entry(window2, width=30, font=('微软雅黑', 10))  # 使用ttk输入框
    entry.pack(pady=10)

    def process_encrypt():
        filename = entry.get() + '.txt'  # 获取输入并添加后缀

        try:  # 读取文件
            with open(filename, 'r', encoding='utf-8') as f:
                msg = f.read()
        except FileNotFoundError:  # 文件不存在则退出程序
            tkm.showerror('错误', '文件不存在，请检查文件名是否正确，或者文件是否在正确的位置。')
            return
        except Exception as e:  # 其他错误则退出程序
            tkm.showerror('读取文件时出现错误', str(e))
            return

        # 检测中文字符
        has_chinese = any('\u4e00' <= char <= '\u9fff' for char in msg)
        if has_chinese:
            tra = tkm.askyesno('提示', '检测到文本中有中文。\n是否打开网站将中文翻译为英文？')
            if tra:
                webbrowser.open('https://fanyi.baidu.com/#zh/en/' + msg)
                tkm.showinfo('提示', '已打开网站，请将中文翻译为英文后再次运行程序。')
            return

        # 换大写
        msg = msg.upper()

        # 凯撒加密
        msg1 = ''
        for letter in msg:
            if 'A' <= letter <= 'Z':
                value = ord(letter) + 13
                if value > ord('Z'):
                    value -= 26
                letter = chr(value)
            msg1 += letter

        # 密文转化
        try:
            with open('密文.txt', 'w', encoding='utf-8') as f1:
                f1.write(msg1)
            tkm.showinfo('提示', '加密完成')
            window2.destroy()  # 关闭窗口
        except Exception as e:
            tkm.showerror('错误', f'写入文件时出现错误：{e}')

    # 使用ttk按钮
    confirm_btn = ttk.Button(window2, text="确定", command=process_encrypt)
    confirm_btn.pack(pady=10)

def unencrypt():
    window2 = tk.Toplevel()  # 使用Toplevel而不是Tk创建新窗口
    window2.title("解密")
    window2.geometry("500x200")

    label = ttk.Label(window2, text="请输入需要解密的文件名（不加后缀）：", font=('微软雅黑', 12))
    label.pack(pady=10)

    entry = ttk.Entry(window2, width=30, font=('微软雅黑', 10))
    entry.pack(pady=10)

    def process_unencrypt():
        filename = entry.get() + '.txt'

        try:
            with open(filename, 'r', encoding='utf-8') as f:
                msg = f.read()
        except FileNotFoundError:  # 文件不存在则退出程序
            tkm.showerror('错误', '文件不存在，请检查文件名是否正确，或者文件是否在正确的位置。')
            return
        except Exception as e:  # 其他错误则退出程序
            tkm.showerror('读取文件时出现错误', str(e))
            return

        # 凯撒解密
        msg1 = ''
        for letter in msg:
            if 'A' <= letter <= 'Z':
                value = ord(letter)
                value = (value - 65 + 13) % 26 + 65
                letter = chr(value)
            msg1 += letter

        # 将解密后的文本分割成句子
        sentences = msg1.split('. ')

        # 对每个句子的首字母大写，其余小写
        sentences = [sentence.capitalize() for sentence in sentences]

        # 将句子重新组合成文本
        msg1 = '. '.join(sentences)

        # 密文转化
        try:
            with open('解密.txt', 'w', encoding='utf-8') as f1:
                f1.write(msg1)

            tra = tkm.askyesno('提示', '解密完成！\n是否打开网站将英文翻译为中文？')
            if tra:
                webbrowser.open('https://fanyi.baidu.com/#en/zh/' + msg1)
                tkm.showinfo('提示', '已打开网站，请将英文翻译为中文后可更有效解密。')
            window2.destroy()  # 关闭窗口
        except Exception as e:
            tkm.showerror('错误', f'写入文件时出现错误：{e}')

    # 使用ttk按钮
    confirm_btn = ttk.Button(window2, text="确定", command=process_unencrypt)
    confirm_btn.pack(pady=10)

# 主窗口
window = tk.Tk()
window.title('凯撒加密器')
window.geometry('600x300')

# 设置ttk样式
style = ttk.Style()
style.configure('TButton', font=('微软雅黑', 10), padding=6)
style.configure('TLabel', font=('微软雅黑', 10))

# 欢迎语
title_label = ttk.Label(window, text="欢迎使用凯撒加密器", font=('微软雅黑', 20))
title_label.pack(pady=10)

notice_label = ttk.Label(window, text="请注意：程序需要和需要加密或需要解密的文本文件放在同一个文件夹下，若已有解密或加密的文件将会覆盖。文件必须为txt格式。\n若文本中有中文，请先将中文翻译为英文后再进行加密，解密后可将英文翻译为中文以获得更好的效果。",
                       wraplength=550)  # 使用ttk标签
notice_label.pack()

browse_label = ttk.Label(window, text="请选择需要进行的操作：", font=('微软雅黑', 12))
browse_label.pack(pady=10)

# 使用ttk按钮
encrypt_btn = ttk.Button(window, text="加密", command=encrypt)
encrypt_btn.pack(pady=10)

decrypt_btn = ttk.Button(window, text="解密", command=unencrypt)
decrypt_btn.pack(pady=10)

window.mainloop()